from backend.config_loader import get_kpi_definition


ROLE_MAP = {
    "Executive": "executive",
    "Analyst": "analyst",
    "Manager": "manager"
}


def check_kpi_access(kpi: str, persona: str) -> bool:
    """
    Check whether the requested persona is authorized
    to access the KPI according to the governed KPI contract.
    """

    role = ROLE_MAP.get(persona)

    if role is None:
        return False

    try:
        kpi_definition = get_kpi_definition(kpi.lower())
    except Exception:
        return False

    allowed_roles = kpi_definition.get("access", {}).get("roles", [])

    return role in allowed_roles


def enforce_kpi_access(kpi: str, persona: str):
    """
    Raise an authorization error when a persona does not
    have access to the requested KPI.
    """

    if not check_kpi_access(kpi, persona):
        raise PermissionError(
            f"Access denied: persona '{persona}' is not authorized "
            f"to access KPI '{kpi}'."
        )