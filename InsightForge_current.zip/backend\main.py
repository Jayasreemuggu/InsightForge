from fastapi import FastAPI
import numpy as np
import pandas as pd

from backend.analysis_pipeline import run_analysis


app = FastAPI(title="InsightForge API")


@app.get("/")
def home():
    return {"message": "InsightForge API is running"}


@app.get("/health")
def health():
    return {"status": "healthy"}


def make_json_safe(obj):
    """
    Recursively convert NumPy/pandas objects
    into standard Python JSON-compatible objects.
    """

    if isinstance(obj, dict):
        return {
            str(key): make_json_safe(value)
            for key, value in obj.items()
        }

    if isinstance(obj, list):
        return [
            make_json_safe(value)
            for value in obj
        ]

    if isinstance(obj, tuple):
        return [
            make_json_safe(value)
            for value in obj
        ]

    if isinstance(obj, pd.DataFrame):
        return make_json_safe(
            obj.to_dict(orient="records")
        )

    if isinstance(obj, pd.Series):
        return make_json_safe(
            obj.tolist()
        )

    if isinstance(obj, np.integer):
        return int(obj)

    if isinstance(obj, np.floating):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)

    if isinstance(obj, np.bool_):
        return bool(obj)

    if pd.isna(obj):
        return None

    return obj


@app.post("/analyze")
def analyze(request: dict):

    result = run_analysis(
        sales_file=request["sales_file"],
        feedback_file=request["feedback_file"],
        region=request["region"],
        date=request["date"],
        persona=request.get("persona", "Executive")
    )

    return make_json_safe(result)