import os
import json
import time

from dotenv import load_dotenv
from google import genai


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError(
        "GEMINI_API_KEY is not set. "
        "Please add GEMINI_API_KEY to the .env file."
    )


# ============================================================
# GEMINI CLIENT
# ============================================================

client = genai.Client(
    api_key=api_key,
    http_options={
        "api_version": "v1"
    }
)


# ============================================================
# TELEMETRY
# ============================================================

MODEL_NAME = "gemini-3.6-flash"

# Gemini pricing should be configured here when known.
# Do not invent pricing values.
INPUT_COST_PER_1M_TOKENS = None
OUTPUT_COST_PER_1M_TOKENS = None


def build_telemetry(
    latency_ms=None,
    input_tokens=None,
    output_tokens=None,
    llm_calls=0,
    error=None
):
    """
    Build runtime telemetry for one LLM interaction.
    """

    estimated_cost = None

    if (
        input_tokens is not None
        and output_tokens is not None
        and INPUT_COST_PER_1M_TOKENS is not None
        and OUTPUT_COST_PER_1M_TOKENS is not None
    ):
        estimated_cost = (
            (input_tokens / 1_000_000)
            * INPUT_COST_PER_1M_TOKENS
            +
            (output_tokens / 1_000_000)
            * OUTPUT_COST_PER_1M_TOKENS
        )

    return {
        "model": MODEL_NAME,
        "latency_ms": latency_ms,
        "llm_calls": llm_calls,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": estimated_cost,
        "error": error
    }


# ============================================================
# DEFAULT FALLBACK RESPONSE
# ============================================================

def fallback_response(
    explanation="The AI insight could not be generated.",
    uncertainty="The AI service was unavailable or returned an invalid response.",
    recommended_action="Review the available evidence manually.",
    telemetry=None
):
    return {
        "explanation": explanation,
        "uncertainty": uncertainty,
        "recommended_action": recommended_action,
        "telemetry": telemetry or build_telemetry()
    }


# ============================================================
# CLEAN GEMINI RESPONSE
# ============================================================

def clean_response(response_text: str) -> str:

    if not response_text:
        return ""

    response_text = response_text.strip()

    if response_text.startswith("```json"):

        response_text = response_text[
            len("```json"):
        ].strip()

    elif response_text.startswith("```"):

        response_text = response_text[
            len("```"):
        ].strip()

    if response_text.endswith("```"):

        response_text = response_text[
            :-len("```")
        ].strip()

    return response_text


# ============================================================
# EXTRACT TOKEN USAGE
# ============================================================

def extract_usage(interaction):

    input_tokens = None
    output_tokens = None

    usage = getattr(
        interaction,
        "usage",
        None
    )

    if usage is None:
        return input_tokens, output_tokens

    input_tokens = getattr(
        usage,
        "input_tokens",
        None
    )

    output_tokens = getattr(
        usage,
        "output_tokens",
        None
    )

    return input_tokens, output_tokens


# ============================================================
# GENERATE INSIGHT
# ============================================================

def generate_insight(
    prompt: str,
    persona: str = "Executive"
) -> dict:

    # --------------------------------------------------------
    # Validate prompt
    # --------------------------------------------------------

    if not prompt or not prompt.strip():

        return fallback_response(
            explanation="No analysis prompt was provided.",
            uncertainty=(
                "The AI analysis could not be performed "
                "because the prompt was empty."
            ),
            recommended_action=(
                "Review the available KPI and driver "
                "evidence manually."
            )
        )


    # --------------------------------------------------------
    # Runtime timer
    # --------------------------------------------------------

    start_time = time.perf_counter()


    # --------------------------------------------------------
    # Call Gemini
    # --------------------------------------------------------

    try:

        interaction = client.interactions.create(
            model=MODEL_NAME,
            input=prompt
        )

        latency_ms = (
            time.perf_counter() - start_time
        ) * 1000

        input_tokens, output_tokens = extract_usage(
            interaction
        )

        telemetry = build_telemetry(
            latency_ms=round(latency_ms, 2),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            llm_calls=1
        )

    except Exception as error:

        latency_ms = (
            time.perf_counter() - start_time
        ) * 1000

        error_text = str(error)

        print(
            f"Gemini API error: {error_text}"
        )

        telemetry = build_telemetry(
            latency_ms=round(latency_ms, 2),
            input_tokens=None,
            output_tokens=None,
            llm_calls=1,
            error=error_text
        )

        # ----------------------------------------------------
        # Handle Gemini quota / rate-limit errors
        # ----------------------------------------------------

        if (
            "429" in error_text
            or "quota exceeded" in error_text.lower()
            or "rate limit" in error_text.lower()
        ):

            return fallback_response(
                explanation=(
                    "The verified KPI, driver, and customer "
                    "evidence analysis was completed, but the "
                    "AI explanation is temporarily unavailable "
                    "because the Gemini API quota was exceeded."
                ),
                uncertainty=(
                    "The analytical results remain available. "
                    "The AI-generated interpretation could not "
                    "be produced until the Gemini API quota "
                    "resets. Correlations indicate association "
                    "rather than causation."
                ),
                recommended_action=(
                    "Review the verified KPI movement, observed "
                    "drivers, and supporting customer evidence. "
                    "Retry the AI explanation after the Gemini "
                    "quota resets."
                ),
                telemetry=telemetry
            )

        # ----------------------------------------------------
        # Handle other Gemini API errors
        # ----------------------------------------------------

        return fallback_response(
            explanation=(
                "The verified KPI, driver, and customer "
                "evidence analysis was completed, but the AI "
                "explanation could not be generated because "
                "the Gemini service returned an error."
            ),
            uncertainty=(
                "The underlying AI service returned an error. "
                "The analytical results shown by InsightForge "
                "should be reviewed manually."
            ),
            recommended_action=(
                "Review the KPI, driver analysis, and supporting "
                "evidence manually."
            ),
            telemetry=telemetry
        )


    # --------------------------------------------------------
    # Extract response
    # --------------------------------------------------------

    try:

        response_text = interaction.output_text

    except AttributeError:

        return fallback_response(
            explanation=(
                "The Gemini service returned an "
                "unexpected response."
            ),
            uncertainty=(
                "The AI response did not contain the "
                "expected output text."
            ),
            recommended_action=(
                "Review the available evidence manually."
            ),
            telemetry=telemetry
        )


    # --------------------------------------------------------
    # Validate response
    # --------------------------------------------------------

    response_text = clean_response(
        response_text
    )

    if not response_text:

        return fallback_response(
            explanation="Gemini returned an empty response.",
            uncertainty=(
                "No AI-generated explanation was available."
            ),
            recommended_action=(
                "Review the available KPI and evidence manually."
            ),
            telemetry=telemetry
        )


    # ========================================================
    # PARSE JSON
    # ========================================================

    try:

        insight = json.loads(
            response_text
        )

    except json.JSONDecodeError:

        return fallback_response(
            explanation=response_text,
            uncertainty=(
                "The AI response was not returned in "
                "the expected JSON format. The explanation "
                "is shown as plain text and should be "
                "reviewed manually."
            ),
            recommended_action=(
                "Review the supplied KPI, driver analysis, "
                "and supporting evidence before taking action."
            ),
            telemetry=telemetry
        )


    # ========================================================
    # VALIDATE JSON OBJECT
    # ========================================================

    if not isinstance(insight, dict):

        return fallback_response(
            explanation=(
                "The AI returned an unexpected "
                "response structure."
            ),
            uncertainty=(
                "The Gemini response was valid JSON but "
                "was not a JSON object containing the "
                "expected fields."
            ),
            recommended_action=(
                "Review the available evidence manually."
            ),
            telemetry=telemetry
        )


    # ========================================================
    # EXTRACT EXPECTED FIELDS
    # ========================================================

    explanation = insight.get(
        "explanation"
    )

    uncertainty = insight.get(
        "uncertainty"
    )

    recommended_action = insight.get(
        "recommended_action"
    )


    if not explanation:

        explanation = (
            "No explanation was generated "
            "for the available evidence."
        )


    if not uncertainty:

        uncertainty = (
            "Uncertainty information was not "
            "provided by the AI response."
        )


    if not recommended_action:

        recommended_action = (
            "Review the available evidence "
            "before taking action."
        )


    # ========================================================
    # RETURN STRUCTURED RESULT
    # ========================================================

    return {
        "explanation": str(
            explanation
        ),

        "uncertainty": str(
            uncertainty
        ),

        "recommended_action": str(
            recommended_action
        ),

        "telemetry": telemetry
    }
    