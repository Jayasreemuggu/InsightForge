import pandas as pd

from backend.config_loader import get_kpi_definition
from backend.data_reconciliation import reconcile_sources
from backend.security import enforce_kpi_access

from backend.analytics.change_detection import calculate_percentage_change
from backend.analytics.anomaly_detection import detect_significant_changes
from backend.analytics.driver_analysis import analyze_driver_changes
from backend.analytics.confidence import calculate_confidence

from backend.evidence.retrieval import retrieve_feedback
from backend.evidence.ranking import rank_evidence

from backend.llm.gemini_service import generate_insight


def run_analysis(
    sales_file: str,
    feedback_file: str,
    region: str,
    date: str,
    persona: str = "Executive",
    product_usage_file: str = "data/product_usage.csv",
    renewal_file: str = "data/renewal_data.csv",
    support_file: str = "data/support_tickets.csv"
):
    
    # ============================================================
    # 0.1 Role-based KPI access control
    # ============================================================

    enforce_kpi_access(
        kpi="revenue",
        persona=persona
    )
    
    # ============================================================
    # 0. Load governed KPI semantic contract
    # ============================================================

    kpi_definition = get_kpi_definition("revenue")

    revenue_column = kpi_definition["calculation"]["column"]

    if revenue_column != "revenue":
        raise ValueError(
            f"Expected revenue column, got '{revenue_column}'."
        )

    # ============================================================
    # 1. Reconcile heterogeneous sources
    # ============================================================

    df = reconcile_sources(
        sales_file=sales_file,
        product_usage_file=product_usage_file,
        renewal_file=renewal_file,
        support_file=support_file
    )

    # ============================================================
    # 2. Validate dates
    # ============================================================

    df["date"] = pd.to_datetime(df["date"])

    investigated_date = pd.to_datetime(date)

    # ============================================================
    # 3. Filter region
    # ============================================================

    region_df = (
        df[df["region"] == region]
        .sort_values("date")
        .copy()
    )

    if region_df.empty:
        return {
            "error": (
                f"No data available for region '{region}'."
            ),
            "abstained": True
        }

    # ============================================================
    # 4. Validate investigated period
    # ============================================================

    current_rows = region_df[
        region_df["date"] == investigated_date
    ]

    if current_rows.empty:
        return {
            "error": (
                f"No data available for {region} during "
                f"{date}."
            ),
            "abstained": True
        }

    current_row = current_rows.iloc[0]

    # ============================================================
    # 5. Find previous period
    # ============================================================

    previous_rows = region_df[
        region_df["date"] < investigated_date
    ].sort_values("date")

    if previous_rows.empty:
        return {
            "error": (
                f"No valid KPI change could be calculated for "
                f"{region} during {date}. "
                "A previous period is required for comparison."
            ),
            "abstained": True
        }

    previous_row = previous_rows.iloc[-1]

    # ============================================================
    # 6. Calculate KPI change
    # ============================================================

    previous_revenue = previous_row[revenue_column]
    current_revenue = current_row[revenue_column]

    try:
        change_df = calculate_percentage_change(
        region_df.sort_values("date")
        )

        investigated_change_row = change_df[
            change_df["date"] == investigated_date
        ]

        if investigated_change_row.empty:
            kpi_change = None
        else:
            kpi_change = investigated_change_row.iloc[0]["percentage_change"]

    except Exception:
        kpi_change = None

    # ============================================================
    # 7. Detect material KPI movement
    # ============================================================

    if abs(kpi_change) < 5:
        return {
            "error": (
                f"No significant KPI change detected for "
                f"{region} during {date}. "
                f"The change was {kpi_change:.2f}%, "
                "below the 5% investigation threshold."
            ),
            "abstained": True
        }

    # ============================================================
    # 8. Analyze driver changes
    # ============================================================

    drivers_df = analyze_driver_changes(
        df=region_df,
        region=region,
        date=str(investigated_date.date()),
        target=revenue_column
    )

    if drivers_df is None:
        drivers_df = pd.DataFrame()


    # ============================================================
    # Convert driver DataFrame to dictionaries
    # ============================================================

    if isinstance(drivers_df, pd.DataFrame) and not drivers_df.empty:

        drivers = drivers_df.to_dict(
            orient="records"
        )

    else:

        drivers = []


    # ============================================================
    # 9. Detect significant changes / anomalies
    # ============================================================

    try:

        anomalies = detect_significant_changes(
            change_df,
            investigated_date
        )

    except TypeError:

        try:

            anomalies = detect_significant_changes(
                change_df
            )

        except Exception:

            anomalies = pd.DataFrame()

    except Exception:

        anomalies = pd.DataFrame()


    if anomalies is None:
        anomalies = pd.DataFrame()


    # ============================================================
    # 10. Retrieve customer feedback
    # ============================================================

    # ============================================================
    # Extract driver names
    # ============================================================

    driver_keywords = []

    if isinstance(drivers, pd.DataFrame):

        driver_keywords = (
            drivers["driver"]
            .dropna()
            .astype(str)
            .tolist()
        )

    elif isinstance(drivers, list):

        driver_keywords = [
            str(driver.get("driver"))
            for driver in drivers
            if isinstance(driver, dict)
            and driver.get("driver")
        ]

     

    # ============================================================
    # Expand driver names into customer-feedback keywords
    # ============================================================

    evidence_keywords = []

    for driver in driver_keywords:

        if driver == "product_usage":

            evidence_keywords.extend([
                "product usage",
                "product",
                "usage",
                "feature",
                "features"
            ])

        elif driver == "support_resolution_hours":

            evidence_keywords.extend([
                "support",
                "support tickets",
                "resolution",
                "resolve",
                "response",
                "response time",
                "delays",
                "delayed",
                "slower",
                "unresolved"
            ])

        elif driver == "renewal_rate":

            evidence_keywords.extend([
                "renewal",
                "renew",
                "retention",
                "contract",
                "churn"
            ])

    # Remove duplicates
    evidence_keywords = list(
        dict.fromkeys(evidence_keywords)
    )


    # ============================================================
    # Retrieve feedback
    # ============================================================

    try:

        feedback = retrieve_feedback(
            feedback_file,
            region=region,
            date=str(investigated_date.date()),
            keywords=evidence_keywords
        )

    except TypeError:

        try:

            feedback = retrieve_feedback(
                feedback_file,
                region,
                str(investigated_date.date()),
                evidence_keywords
            )

        except Exception:

            feedback = pd.DataFrame()

    except Exception:

        feedback = pd.DataFrame()

    if feedback is None:
        feedback = pd.DataFrame()
    
    # Remove duplicates while preserving order
    evidence_keywords = list(
        dict.fromkeys(evidence_keywords)
    )

    
    # ============================================================
    # 11. Rank supporting evidence
    # ============================================================

    
    evidence = rank_evidence(
        feedback,
        evidence_keywords
    )

    if evidence is None:
        evidence = pd.DataFrame()

    # ============================================================
    # 12. Attach supporting evidence to drivers
    # ============================================================

    DRIVER_EVIDENCE_TERMS = {
        "product_usage": [
            "product",
            "usage",
            "feature",
            "features"
        ],

        "support_resolution_hours": [
            "support",
            "ticket",
            "tickets",
            "resolution",
            "resolve",
            "response",
            "delay",
            "delays",
            "slower",
            "unresolved",
            "open for several days"
        ],

        "renewal_rate": [
            "renewal",
            "renewals",
            "renew",
            "churn"
        ]
    }

    if isinstance(drivers, pd.DataFrame):

        drivers = drivers.copy()
        drivers["supporting_evidence"] = None

        for index, driver_row in drivers.iterrows():

            driver_name = str(
                driver_row["driver"]
            )

            terms = DRIVER_EVIDENCE_TERMS.get(
                driver_name,
                [driver_name.replace("_", " ")]
            )

            driver_evidence = rank_evidence(
                feedback,
                terms
            )

            supporting = []

            if not driver_evidence.empty:

                supporting = (
                    driver_evidence["feedback"]
                    .head(5)
                    .astype(str)
                    .tolist()
                )

            drivers.at[
                index,
                "supporting_evidence"
            ] = supporting

        drivers = drivers.to_dict(
            orient="records"
        )

        # ============================================================
        # 12B. Assign each feedback item to its best matching driver
        # ============================================================

        DRIVER_EVIDENCE_TERMS = {
            "product_usage": [
                "product usage",
                "product use",
                "product usage has decreased",
                "product usage decreased",
                "product usage dropped",
                "feature",
                "features",
                "feature usage",
                "usage decreased",
                "usage dropped",
            ],

            "support_resolution_hours": [
                "support ticket",
                "support tickets",
                "support response",
                "support responses",
                "response time",
                "response times",
                "support delay",
                "support delays",
                "support resolution",
                "support resolution time",
                "resolution time",
                "tickets taking longer to resolve",
                "support tickets taking longer to resolve",
                "unresolved issue",
                "unresolved issues",
                "open ticket",
                "open tickets",
            ],

            "renewal_rate": [
                "renewal",
                "renewals",
                "renew",
                "retention",
                "churn",
                "contract renewal",
            ],
        }


        def get_driver_evidence_score(feedback_text, terms):
            """
            Calculate driver-specific evidence strength.

            Strong phrases receive higher scores.
            Generic contextual words receive lower scores.
            """

            text = str(feedback_text).lower()

            score = 0

            for term in terms:
                term = term.lower()

                if term in text:
                    # Multi-word phrases are stronger evidence.
                    if " " in term:
                        score += 3
                    else:
                        score += 1

            return score


        # Build driver list if necessary
        if isinstance(drivers, pd.DataFrame):

            drivers = drivers.copy()

            driver_records = drivers.to_dict(
                orient="records"
            )

        else:

            driver_records = drivers


        # Initialize evidence for every driver
        for driver in driver_records:

            if not isinstance(driver, dict):
                continue

            driver["supporting_evidence"] = []


        # Assign each feedback item to ONLY its strongest driver
        if isinstance(evidence, pd.DataFrame) and not evidence.empty:

            for _, evidence_row in evidence.iterrows():

                feedback_text = str(
                    evidence_row.get("feedback", "")
                )

                if not feedback_text.strip():
                    continue

                best_driver = None
                best_score = 0

                for driver in driver_records:

                    if not isinstance(driver, dict):
                        continue

                    driver_name = str(
                        driver.get("driver", "")
                    )

                    terms = DRIVER_EVIDENCE_TERMS.get(
                        driver_name,
                        [driver_name.replace("_", " ")]
                    )

                    score = get_driver_evidence_score(
                        feedback_text,
                        terms
                    )

                    if score > best_score:

                        best_score = score
                        best_driver = driver

                # Only assign evidence when there is an actual match
                if best_driver is not None and best_score > 0:

                    best_driver["supporting_evidence"].append(
                        feedback_text
                    )


        # Limit evidence shown for each driver
        for driver in driver_records:

            if not isinstance(driver, dict):
                continue

            driver["supporting_evidence"] = (
                driver["supporting_evidence"][:5]
            )


        drivers = driver_records
    # ============================================================
    # 13. Historical observations
    # ============================================================

    historical_observations = 0

    if len(region_df) > 1:
        historical_observations = len(
            region_df[
                region_df["date"] < investigated_date
            ]
        )

    # ============================================================
    # 14. Calculate evidence confidence
    # ============================================================

    try:
        confidence = calculate_confidence(
            kpi_change=kpi_change,
            drivers=drivers,
            evidence=evidence
        )
    except TypeError:
        try:
            confidence = calculate_confidence(
                kpi_change,
                drivers,
                evidence
            )
        except Exception:
            confidence = "Moderate"

    if confidence is None:
        confidence = "Moderate"

    # ============================================================
    # 15. Sparse-history protection
    # ============================================================

    if historical_observations < 3:

        return {
            "region": region,
            "date": str(investigated_date.date()),
            "kpi": "Revenue",
            "kpi_change": float(kpi_change),
            "drivers": drivers,
            "evidence": evidence,
            "confidence": "Low",
            "abstained": True,
            "explanation": (
                "The revenue movement was detected, but there is "
                "insufficient historical data to reliably identify "
                "explanatory drivers."
            ),
            "uncertainty": (
                f"Only {historical_observations} historical observations "
                "were available for driver analysis. This is insufficient "
                "to establish a reliable historical relationship. "
                "The system therefore abstains from generating an "
                "AI-based driver explanation."
            ),
            "recommended_action": (
                "Collect additional historical observations before "
                "using driver relationships for decision-making, "
                "and conduct human review of the current revenue movement."
            )
        }

    # ============================================================
    # 16. Persona-specific instruction
    # ============================================================

    if persona == "Executive":

        persona_instruction = """
Persona: Executive

Provide a concise business-focused explanation.

Focus on:
- What changed
- Business impact
- Most important observed drivers
- Supporting customer evidence
- Recommended business action

Avoid unnecessary statistical detail.
"""

    elif persona == "Analyst":

        persona_instruction = """
Persona: Analyst

Provide a detailed analytical explanation.

Include:
- KPI movement
- Driver changes
- Correlations
- p-values
- Historical observations
- Evidence supporting each driver
- Uncertainty and limitations
- Recommended action

Clearly distinguish association from causation.
"""

    else:

        persona_instruction = """
Persona: Executive

Provide a concise business-focused explanation.

Focus on:
- KPI movement
- Important observed drivers
- Supporting evidence
- Uncertainty
- Recommended action

Avoid unnecessary statistical detail.
"""

    # ============================================================
    # 17. Build LLM prompt
    # ============================================================

    prompt = f"""
You are InsightForge, an evidence-driven
business intelligence assistant.

{persona_instruction}

Analyze the following VERIFIED business data.

KPI: Revenue
Region: {region}
Period: {date}
Revenue change: {kpi_change:.2f}%

Previous revenue: {previous_revenue}
Current revenue: {current_revenue}

Observed driver analysis:

{drivers}

Supporting customer evidence:

{evidence}

Historical observations:

{historical_observations}

Evidence strength:

{confidence}

Interpretation rules:

- percentage_change is the observed
  month-over-month driver change.

- correlation represents historical
  association with revenue using the
  available pre-period observations.

- direction_alignment indicates whether
  the current driver movement is
  directionally consistent with its
  historical relationship with revenue.

- driver_score ranks observed driver
  strength using change magnitude and
  historical association.

- supporting_evidence contains customer
  feedback specifically matched to that
  driver.

- A driver without supporting_evidence
  does NOT have direct qualitative
  customer evidence.

- Correlation and driver scores indicate
  association, not causation.

- historical_observations is the number
  of pre-period observations used to
  calculate the historical correlation.

- Correlations based on a small number
  of observations should be treated
  cautiously.

- correlation_reliability describes the
  reliability of the historical correlation
  based only on the number of available
  pre-period observations.

- Do not describe Limited or Very Limited
  correlations as strong evidence.

- correlation_p_value represents the
  p-value of the historical Pearson
  correlation.

- correlation_significance indicates
  whether the correlation passes the
  0.05 significance threshold.

- Statistical significance does not
  establish causation.

IMPORTANT STATISTICAL INTERPRETATION RULES:

- The supplied correlation_significance
  field is authoritative.

- Do not recalculate or override the
  supplied significance classification.

- If correlation_significance is
  "Statistically significant", describe it
  as statistically significant.

- If correlation_significance is
  "Not statistically significant", describe
  it as not statistically significant.

- Always mention historical_observations
  and correlation_reliability when
  discussing correlations.

- Statistical significance does not
  establish causation.

- Limited or Very Limited correlation
  reliability must be clearly stated.

RULES:

- Do not claim causation.
- Preserve driver-specific statistical
  results exactly.
- Do not merge, average, or generalize
  p-values across drivers.
- Do not merge statistical-significance
  labels across drivers.
- Describe drivers as observed associations.
- Use only the supplied evidence.
- Do not invent facts.
- Do not claim qualitative evidence exists
  when supporting_evidence is empty.
- Clearly communicate uncertainty.
- Treat evidence strength as a heuristic,
  not statistical confidence.
- Recommend one practical business action.
- Human review remains necessary.

Return ONLY valid JSON using exactly
this structure:

{{
    "explanation":
        "Brief evidence-grounded explanation",

    "uncertainty":
        "Explain limitations and alternative explanations",

    "recommended_action":
        "One practical next-best action"
}}
"""

    # ============================================================
    # 18. Generate structured AI insight
    # ============================================================

    try:

        insight = generate_insight(
            prompt,
            persona=persona
        )

    except Exception as exc:

        insight = {
            "explanation": (
                "The verified KPI, driver, and customer evidence "
                "analysis was completed, but the AI explanation "
                "is temporarily unavailable."
            ),
            "uncertainty": (
                "The analytical results remain available. "
                f"The AI generation step failed with: {str(exc)}"
            ),
            "recommended_action": (
                "Review the verified KPI movement, observed "
                "drivers, and supporting customer evidence."
            )
        }

    # ============================================================
    # 19. Handle empty AI response
    # ============================================================

    if insight is None:

        insight = {
            "explanation": (
                "The verified KPI, driver, and customer evidence "
                "analysis was completed, but no AI explanation "
                "was returned."
            ),
            "uncertainty": (
                "The deterministic analytical results remain "
                "available. The AI narrative could not be generated."
            ),
            "recommended_action": (
                "Review the verified KPI movement, observed "
                "drivers, and supporting customer evidence."
            )
        }

    # ============================================================
    # 20. Normalize AI response
    # ============================================================

    if not isinstance(insight, dict):

        insight = {
            "explanation": str(insight),
            "uncertainty": (
                "The AI response was returned in an unexpected format."
            ),
            "recommended_action": (
                "Review the verified analytical results manually."
            )
        }

    explanation = insight.get(
        "explanation",
        "No AI explanation was generated."
    )

    uncertainty = insight.get(
        "uncertainty",
        "Uncertainty information was not returned."
    )

    recommended_action = insight.get(
        "recommended_action",
        "Review the verified analytical results."
    )

    # ============================================================
    # 21. Return complete analysis
    # ============================================================

    return {
        "region": region,
        "date": str(investigated_date.date()),

        "kpi": "Revenue",
        "kpi_change": float(kpi_change),

        "previous_revenue": float(previous_revenue),
        "current_revenue": float(current_revenue),

        "drivers": drivers,
        "evidence": evidence,

        "confidence": confidence,
        "abstained": False,

        "anomalies": anomalies,

        "persona": persona,

        "explanation": explanation,
        "uncertainty": uncertainty,
        "recommended_action": recommended_action,

        "telemetry": insight.get(
        "telemetry",
        {}
    )
}